
public class Sample1 {
	public static void main (String[] args) {
		System.out.print("�}�l�ϥ�java!!");
		System.out.print("Hello World!!");
		
	}

}
