
public class Sample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println('V');
		System.out.println("�A�n!");
		System.out.println(123456);
	}

}
