package test_p31;

public class Sample11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("10+20="+(10+20));
		System.out.println("5*6="+(5*6));
		int num1=10;
		int num2=56;
		int sum =num1+num2;
		System.out.println("�ܼƭ�num1����="+num1);
		System.out.println("�ܼƭ�num2����="+num2);
		System.out.println("num1+num2="+sum);
		num1=num1+2;
		System.out.println("�ܼ�num1����+2="+num1);
	}

}
