
public class Sample7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		num=4;
		System.out.println("�ܼƭ�num���ȬO"+num);
	}

}
