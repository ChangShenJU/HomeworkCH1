
public class Sample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("��ܥX�ϱ׽u:\\");
		System.out.println("��ܥX��޸�:\"");
	}

}
